A Pen created at CodePen.io. You can find this one at http://codepen.io/NickyCDK/pen/AIonk.

 Christmas is coming up, so wanted to try out making some snow with a CSS3 animation